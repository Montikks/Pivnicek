
package com.pivnicek

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine

class BeerViewModel : ViewModel() {
    private val _count = MutableStateFlow(0)
    private val _price = MutableStateFlow(0.0)

    val count: StateFlow<Int> = _count
    val pricePerBeer: StateFlow<Double> = _price
    val total: StateFlow<Double> = combine(_count, _price) { c, p -> c * p }

    fun addBeer() {
        _count.value = _count.value + 1
    }

    fun setPrice(price: Double) {
        _price.value = price
    }
}
