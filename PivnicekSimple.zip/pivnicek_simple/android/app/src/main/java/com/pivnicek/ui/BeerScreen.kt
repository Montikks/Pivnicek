
package com.pivnicek.ui

import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.pivnicek.BeerViewModel

@Composable
fun BeerScreen(viewModel: BeerViewModel) {
    val count by viewModel.count.collectAsState()
    val price by viewModel.pricePerBeer.collectAsState()
    val total by viewModel.total.collectAsState(0.0)

    var priceInput by remember { mutableStateOf(if (price == 0.0) "" else price.toString()) }

    Column(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, dragAmount ->
                    if (dragAmount > 80f) viewModel.addBeer()
                }
            }
            .padding(24.dp)
    ) {
        Text("Počet piv:", style = MaterialTheme.typography.titleLarge)
        Text("$count", style = MaterialTheme.typography.displayLarge)
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = priceInput,
            onValueChange = {
                priceInput = it
                it.toDoubleOrNull()?.let(viewModel::setPrice)
            },
            label = { Text("Cena za pivo (Kč)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(24.dp))
        Text("Celkem:", style = MaterialTheme.typography.titleLarge)
        Text(String.format("%.2f Kč", total), style = MaterialTheme.typography.displayMedium)
        Spacer(Modifier.height(24.dp))
        Text(
            "Gesto: přetáhněte prstem shora dolů kdekoliv na obrazovce pro přidání piva.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
